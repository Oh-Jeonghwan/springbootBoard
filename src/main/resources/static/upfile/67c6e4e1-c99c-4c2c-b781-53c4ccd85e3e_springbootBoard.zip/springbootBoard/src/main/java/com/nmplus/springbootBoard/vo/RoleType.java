package com.nmplus.springbootBoard.vo;

public enum RoleType {
	USER, ADMIN

}
