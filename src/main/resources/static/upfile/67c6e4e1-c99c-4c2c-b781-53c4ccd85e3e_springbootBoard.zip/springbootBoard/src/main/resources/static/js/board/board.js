/**
 * 
 */
let index={
	init: function(){
		
	}
	
}


index.init();